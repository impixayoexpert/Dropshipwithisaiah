# DropshipWithIsaiah

Premium ecommerce & dropshipping agency website built with React + Vite.

## 🚀 Getting Started

### Install dependencies
```bash
npm install
```

### Run locally
```bash
npm run dev
```
Open [http://localhost:5173](http://localhost:5173)

### Build for production
```bash
npm run build
```

## 📦 Deploy to Netlify

### Option 1 — Connect GitHub repo (Recommended)
1. Push this repo to GitHub
2. Go to [netlify.com](https://netlify.com) → **Add new site** → **Import from Git**
3. Select your repo
4. Build command: `npm run build`
5. Publish directory: `dist`
6. Click **Deploy** ✅

### Option 2 — Drag & drop
1. Run `npm run build`
2. Drag the `dist` folder to [app.netlify.com/drop](https://app.netlify.com/drop)

## 📁 Project Structure

```
├── index.html          # HTML entry point
├── vite.config.js      # Vite config
├── netlify.toml        # Netlify deployment config
├── package.json
└── src/
    ├── main.jsx        # React entry point
    └── App.jsx         # Full website (all pages)
```

## 📞 Contact
- WhatsApp: https://wa.link/4o42bb
- Telegram: @dropshipwithisaiah
- Email: dropshipwithisaiah@gmail.com
